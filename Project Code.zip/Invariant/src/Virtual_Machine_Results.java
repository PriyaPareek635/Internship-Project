
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import java.sql.*;
 
public class Virtual_Machine_Results {
    public static void main(String[] args) {
        
  int count=0;
  int count1=0;
  double c1=0.0;
  double c2=0.0;
  double c3=0.0;
  double c4=0.0;
  double c5=0.0;
  double c6=0.0;
  double c7=0.0;
  double c8=0.0;
  double c11=0.0;
  double c22=0.0;
  double c33=0.0;
  
  String fname=null,fname1=null,fname2=null,fname3=null,fname4=null,fname5=null,fname6=null,fname7=null;
  
    	try
    	{
    		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};Dbq=src\\Database.mdb");
			
    	    Statement st=con.createStatement();
    		ResultSet rs=st.executeQuery("select * from Allocate");
    		
    		while(rs.next()==true)
    		{
    			count++;
    			if(count==1)
    			{
    				fname=rs.getString("VM");
    				c1=Double.valueOf(rs.getString("Memory"));
    				c11=Double.valueOf(rs.getString("Threshold"));
    				
    			}
    			
    			if(count==2)
    			{
    				fname1=rs.getString("VM");
    				c2=Double.valueOf(rs.getString("Memory"));
    				c22=Double.valueOf(rs.getString("Threshold"));
    				
    			}
    			
    			
    		}
    		    DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
    	        dataSet.setValue(c1, "TH1-"+c11, String.valueOf(fname));
    	        dataSet.setValue(c2, "TH2-"+c22, String.valueOf(fname1));
    	        
    	         
    	        JFreeChart chart = ChartFactory.createLineChart3D("Assessing Invariant Mining Techniques for Cloud-based Utility Computing Systems", "Virtual Machine Memory ", "Total Memory", "dataSet", PlotOrientation.VERTICAL, true, true, true);
    	        ChartFrame chartFrame=new ChartFrame("Different Transaction VM Details",chart);
    	        chartFrame.setVisible(true);
    	        chartFrame.setSize(600,500);
    	}
    	catch(Exception ex)
    	{
    	System.out.println(ex);	
    		
    	}
    
}
}