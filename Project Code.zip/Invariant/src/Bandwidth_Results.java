
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import java.sql.*;
 
public class Bandwidth_Results {
    public static void main(String[] args) {
        
  int count=0;
  int count1=0;
  double c1=0.0;
  double c2=0.0;
  double c3=0.0;
  double c4=0.0;
  double c5=0.0;
  double c6=0.0;
  double c7=0.0;
  double c8=0.0;
  
  String fname=null,fname1=null,fname2=null,fname3=null,fname4=null,fname5=null,fname6=null,fname7=null;
  
    	try
    	{
    		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};Dbq=src\\Database.mdb");
			
    	    Statement st=con.createStatement();
    		ResultSet rs=st.executeQuery("select * from Bandwidth");
    		
    		while(rs.next()==true)
    		{
    			count++;
    			if(count==1)
    			{
    				fname=rs.getString("VName");
    				c1=Double.valueOf(rs.getString("Bandwidth"));
    				
    			}
    			
    			if(count==2)
    			{
    				fname1=rs.getString("VName");
    				c2=Double.valueOf(rs.getString("Bandwidth"));
    			}
    			
    		}
    		    DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
    	        dataSet.setValue(c1, "BW1", String.valueOf(fname));
    	        dataSet.setValue(c2, "BW2", String.valueOf(fname1));
    	       
    	 
    	        JFreeChart chart = ChartFactory.createBarChart3D("Assessing Invariant Mining Techniques for Cloud-based Utility Computing Systems", "Bandwidth ", "Total Bandwidth",
    	                dataSet, PlotOrientation.VERTICAL, true, true, true);
    	        ChartFrame chartFrame=new ChartFrame("Different Transaction Upload Bandwidth Details",chart);
    	        chartFrame.setVisible(true);
    	        chartFrame.setSize(600,500);
    	}
    	catch(Exception ex)
    	{
    	System.out.println(ex);	
    		
    	}
    
}
}